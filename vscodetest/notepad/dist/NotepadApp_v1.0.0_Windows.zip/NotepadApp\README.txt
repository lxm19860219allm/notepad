NotepadApp - Tabbed Notepad Application 
 
Features: 
- Multiple tab support 
- Auto-save functionality 
- JSON file format 
- Modern user interface 
 
Usage: 
1. Run NotepadApp.exe 
2. Use "Add Tab" to create new tabs 
3. Edit content in the right panel 
4. Use File menu to save/open files 
